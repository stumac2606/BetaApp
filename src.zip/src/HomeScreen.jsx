// HomeScreen.jsx (Refactored)
import React, { useState, useEffect } from "react";
import { Typography, List, Card, message, Avatar, Button, Space } from "antd";
import { PlayCircleOutlined, UserOutlined, LikeOutlined, ShareAltOutlined } from "@ant-design/icons";
import axios from "axios";
import "./HomeScreen.css";

const { Title, Text } = Typography;
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const HomeScreen = () => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(false);
  const username = localStorage.getItem("username") || "";
  const token = localStorage.getItem("access_token");

  useEffect(() => {
    const fetchVideos = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`${API_BASE_URL}/videoFiles/`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setVideos(response.data);
      } catch (error) {
        message.error("Failed to fetch videos: " + (error.response?.data?.detail || "Unknown error"));
      } finally {
        setLoading(false);
      }
    };

    fetchVideos();
  }, [token]);

  return (
    <div className="home-screen-container">
      <Title level={4} style={{ marginBottom: 24 }}>Recent Videos</Title>
      <List
        loading={loading}
        grid={{ gutter: 16, column: 1 }}
        dataSource={videos}
        renderItem={(video) => (
          <List.Item>
            <Card className="video-card" hoverable>
              <div className="video-header">
                <Avatar size="large" icon={<UserOutlined />} />
                <Text strong className="video-username">{username}</Text>
              </div>
              <VideoPlayer videoId={video.video_id} />
              <div className="video-actions">
                <Space>
                  <Button type="link" icon={<PlayCircleOutlined />} className="action-button">See Analysis</Button>
                  <Button type="link" icon={<LikeOutlined />} className="action-button">Like</Button>
                  <Button type="link" icon={<ShareAltOutlined />} className="action-button">Share</Button>
                </Space>
              </div>
            </Card>
          </List.Item>
        )}
      />
    </div>
  );
};

const VideoPlayer = ({ videoId }) => {
  const [videoSrc, setVideoSrc] = useState(null);

  useEffect(() => {
    const fetchVideo = async () => {
      const token = localStorage.getItem("access_token");
      if (!token) {
        message.error("No access token found.");
        return;
      }

      try {
        const response = await fetch(`${API_BASE_URL}/stream_video/${videoId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch video");
        }

        const blob = await response.blob();
        setVideoSrc(URL.createObjectURL(blob));
      } catch (error) {
        message.error("Failed to load video: " + error.message);
      }
    };

    fetchVideo();

    return () => {
      if (videoSrc) URL.revokeObjectURL(videoSrc);
    };
  }, [videoId]);

  return (
    <div className="video-container">
      {videoSrc ? (
        <video controls width="100%" className="video-player" src={videoSrc} />
      ) : (
        <p>Loading video...</p>
      )}
    </div>
  );
};

export default HomeScreen;