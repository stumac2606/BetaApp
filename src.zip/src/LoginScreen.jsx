import React, { useState } from "react";
import { Button, Input, Form, Typography, message } from "antd";
import axios from "axios";
import "./LoginScreen.css"; // Optional, see below

const { Title } = Typography;
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const LoginScreen = ({ onLogin }) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const handleLogin = async (values) => {
    const { email, password } = values;

    try {
      setLoading(true);
      const response = await axios.post(`${API_BASE_URL}/auth/login/`, {
        email: email.trim().toLowerCase(),
        password,
      });

      const { access_token, username } = response.data;
      localStorage.setItem("access_token", access_token);
      localStorage.setItem("username", username);
      onLogin(); // callback from App.jsx
    } catch (error) {
      const detail = error.response?.data?.detail || "Unknown error";
      message.error(`Login failed: ${detail}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen-container">
      <Title level={4} style={{ marginBottom: 24 }}>Existing Users</Title>
      <Form
        form={form}
        layout="vertical"
        onFinish={handleLogin}
        requiredMark={false}
      >
        <Form.Item
          name="email"
          rules={[
            { required: true, message: "Email is required" },
            { type: "email", message: "Enter a valid email" },
          ]}
        >
          <Input placeholder="Email" />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[{ required: true, message: "Password is required" }]}
        >
          <Input.Password placeholder="Password" />
        </Form.Item>

        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            block
            loading={loading}
            style={{ height: 42 }}
          >
            Login
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default LoginScreen;
