import React, { useState, useEffect } from "react";
import { Button, List, message, Typography, Card } from "antd";
import axios from "axios";
import "./AnalysisFilesScreen.css";

const { Title, Text } = Typography;
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const AnalysisFilesScreen = () => {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const token = localStorage.getItem("access_token");

  useEffect(() => {
    const fetchFiles = async () => {
      setLoading(true);
      try {
        const { data } = await axios.get(`${API_BASE_URL}/files/`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setFiles(data);
      } catch (error) {
        message.error("Failed to fetch files: " + (error.response?.data?.detail || "Unknown error"));
      } finally {
        setLoading(false);
      }
    };

    fetchFiles();
  }, [token]);

  const handleDownload = async (fileId, filename, contentType) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/files/${fileId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        responseType: "blob",
      });

      const blob = new Blob([response.data], { type: contentType });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading file:", error);
      message.error(`Download failed: ${error.response?.data?.detail || "Unknown error"}`);
    }
  };

  const downloadAll = async (type) => {
    for (const file of files) {
      if (type === "videos" && file.video_id) {
        await handleDownload(file.video_id, file.processed_filename, "video/mp4");
      } else if (type === "jsons" && file.json_id) {
        await handleDownload(file.json_id, file.json_filename, "application/json");
      }
    }
  };

  return (
    <div className="analysis-files-screen">
      <Title level={2}>Your Files</Title>

      <div className="download-controls">
        <Button type="primary" onClick={() => downloadAll("videos")}>
          Download All Videos
        </Button>
        <Button type="primary" onClick={() => downloadAll("jsons")}>
          Download All JSONs
        </Button>
      </div>

      <List
        loading={loading}
        grid={{ gutter: 16, column: 1 }}
        dataSource={files}
        renderItem={({ filename, processed_filename, json_filename, uploaded_at, video_id, json_id }) => (
          <List.Item>
            <Card className="file-card">
              <Text strong>Original Filename:</Text> {filename || "N/A"}
              <br />
              <Text strong>Processed Filename:</Text> {processed_filename || "N/A"}
              <br />
              <Text strong>JSON Filename:</Text> {json_filename || "N/A"}
              <br />
              <Text strong>Uploaded at:</Text> {uploaded_at || "Unknown"}

              <div className="button-group">
                <Button type="primary" onClick={() => handleDownload(video_id, processed_filename, "video/mp4")}>
                  Download Video
                </Button>
                <Button type="primary" onClick={() => handleDownload(json_id, json_filename, "application/json")}>
                  Download JSON
                </Button>
              </div>
            </Card>
          </List.Item>
        )}
      />
    </div>
  );
};

export default AnalysisFilesScreen;
