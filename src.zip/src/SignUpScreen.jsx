import React, { useState } from "react";
import { Button, Input, Form, Typography, message } from "antd";
import axios from "axios";
import "./SignUpScreen.css"; // optional, for custom styling

const { Title } = Typography;
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const SignUpScreen = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const handleSignUp = async (values) => {
    const { username, email, password } = values;

    try {
      setLoading(true);
      const response = await axios.post(`${API_BASE_URL}/auth/signup/`, {
        username: username.trim(),
        email: email.trim().toLowerCase(),
        password,
      });
      message.success(response.data.message || "Sign up successful!");
      form.resetFields();
    } catch (error) {
      const detail = error.response?.data?.detail || "Unknown error";
      message.error(`Sign up failed: ${detail}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="signup-screen-container">
      <Title level={4} style={{ marginBottom: 24 }}>New Users</Title>
      <Form
        layout="vertical"
        form={form}
        onFinish={handleSignUp}
        requiredMark={false}
      >
        <Form.Item
          name="username"
          rules={[{ required: true, message: "Username is required" }]}
        >
          <Input placeholder="Username" />
        </Form.Item>

        <Form.Item
          name="email"
          rules={[
            { required: true, message: "Email is required" },
            { type: "email", message: "Enter a valid email" },
          ]}
        >
          <Input placeholder="Email" />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[{ required: true, message: "Password is required" }]}
        >
          <Input.Password placeholder="Password" />
        </Form.Item>

        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            block
            loading={loading}
          >
            Sign Up
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default SignUpScreen;
